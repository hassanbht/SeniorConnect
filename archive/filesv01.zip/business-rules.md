# Business Rules

> These rules are binding. Code that violates a rule here is a defect regardless of tests.
> Changing a rule requires an ADR in `docs/decisions/`.

---

## 1. Scope of mediation (BR-SCOPE)

**BR-SCOPE-01** Mitanand mediates only **non-medical, non-nursing, unpaid** everyday help
and social activities.

**BR-SCOPE-02** The following categories are permanently blocked and can never be created
as a `HelpRequest`:

```
personal hygiene / Körperpflege
medication administration
wound care, injections, any clinical procedure
lifting or transferring a person
any task offered or requested for payment between private individuals
overnight / 24-hour care
```

**BR-SCOPE-03** When a user's request text or chosen category triggers a blocked topic,
the system responds with a **referral** (contact details of professional services in the
region) and does **not** create a request. This event is logged as
`BlockedCategoryReferral` for product learning.

**BR-SCOPE-04** Any request describing symptoms of an acute medical emergency triggers the
**Emergency path**: display 144 / 112 prominently, offer to call, notify trusted contacts
if configured. It is never converted into a normal help request. This applies to voice
input in later phases as well.

**BR-SCOPE-05** Emergency ≠ Safety Alert. "Emergency" routes to official services.
"Safety Alert" (senior did not arrive, volunteer raised a concern, family requested a
welfare check) is an internal workflow and must never be presented as an emergency service.

---

## 2. Identity, trust and capability (BR-TRUST)

**BR-TRUST-01** Three concepts are separate and must never be merged in code:

```
Identity  — is this person who they claim to be?
Trust     — how much has been verified about them?
Capability— what are they allowed to do right now?
```

**BR-TRUST-02** Trust levels:

| Level | Name | Achieved by |
| --- | --- | --- |
| 0 | Registered | account created |
| 1 | Contact Verified | email **and** phone verified |
| 2 | Identity Verified | identity confirmed via an approved provider or manual staff review |
| 3 | Address Verified | address confirmed (Meldebestätigung, postal code letter, or org confirmation) |
| 4 | Organization Verified | an organization vouches for this person |
| 5 | Safety Verified | background check recorded **and** required training completed **and** organization approval |

**BR-TRUST-03** Trust level is **computed server-side** from verification records. It is
never stored as a client-writable field and never sent by the client.

**BR-TRUST-04** The platform never asserts that a person is safe. Badges state
*what was verified, by whom, and when*. UI copy must reflect this.

**BR-TRUST-05** Verification documents (ID scans, Strafregisterbescheinigung) are
**not stored** by the platform in MVP. Only the outcome is stored:

```
verification_type, status, verified_by_org_id, verified_by_user_id,
verified_at, valid_until, external_reference
```

**BR-TRUST-06** Identity verification is behind `IIdentityVerificationProvider`.
MVP implementation: `ManualVerificationProvider` + `OrganizationVerificationProvider`.
`IdAustriaProvider` and `KycProvider` are added later with **zero business-logic change**.

**BR-TRUST-07** Verifications expire. An expired verification silently reduces the
computed trust level; the affected user is notified and their assignments above the new
level are flagged for the coordinator — **never auto-cancelled without a human seeing it**.

---

## 3. Safety levels (BR-SAFETY)

**BR-SAFETY-01** Every activity and help-request category has a **required safety level**,
determined **exclusively server-side** by `IActivitySafetyPolicy`. The client sends only
the category and context.

**BR-SAFETY-02** Reference mapping (configurable, not hardcoded):

| Level | Description | Example | Minimum trust |
| --- | --- | --- | --- |
| 1 | Public, group, no isolation | walking group, café meetup | 1 |
| 2 | One-to-one, public space | shopping together, accompaniment to a shop | 2 |
| 3 | One-to-one, semi-private / institutional | doctor's appointment, Behördengang | 3 + org or platform review |
| 4 | Inside the person's home | home visit, repairs, help unpacking | 5 + org approval |
| 5 | Home visit with a person flagged as highly vulnerable | cognitive impairment, no family contact | 5 + org approval + named coordinator |

**BR-SAFETY-03** Matching invariant:

```
volunteer.effectiveTrustLevel >= request.requiredTrustLevel
AND volunteer has all required capabilities
AND organization policy permits
```
All three conditions are evaluated server-side. Failing any one excludes the candidate.

**BR-SAFETY-04** The same category can require different levels in different contexts
(e.g. "shopping" in public = L2, "collect medication and bring it into the flat" = L4).
`IActivitySafetyPolicy` receives the full context, not just the category enum.

**BR-SAFETY-05** **Buddy rule.** A volunteer's **first three** Level-3+ activities must be
either accompanied by an experienced volunteer or explicitly waived by a coordinator, with
the waiver recorded and attributed.

**BR-SAFETY-06** Insurance context is recorded on every assignment:
`OrganizationCovered | PrivateNeighbourly | Unknown`. Level 3+ assignments require
`OrganizationCovered`, or an explicit acknowledged disclaimer that is stored with the
assignment.

---

## 4. Help request lifecycle (BR-HELP)

**BR-HELP-01** States:

```
Draft → Open → Matching → Offered → Assigned → InProgress → Completed
                    ↓         ↓         ↓          ↓
                 Cancelled  Cancelled Cancelled  Cancelled
                                                     ↓
                                                 NoShow
                          Open → Expired (no match before the date)
```

**BR-HELP-02** Only these transitions are legal. Any other transition attempt is a
`409 Conflict` with a machine-readable reason code.

**BR-HELP-03** Assignment is **atomic and race-safe**. Use a conditional update:

```sql
UPDATE help_requests
   SET assigned_volunteer_id = @v, status = 'assigned', row_version = row_version + 1
 WHERE id = @id AND status = 'offered' AND row_version = @rv;
```
`RowsAffected = 0` → someone else took it → return 409 with `HELP_ALREADY_ASSIGNED`.

**BR-HELP-04** A request created by a family member on behalf of a senior records **both**
`created_by_user_id` and `subject_user_id`, and requires the corresponding
`FamilyPermission.CanCreateHelpRequests`.

**BR-HELP-05** Cancellation always requires a reason from a fixed list plus optional free
text. Reasons feed reliability metrics.

**BR-HELP-06** `NoShow` can only be set at least 30 minutes after the scheduled start, by
the counterparty or a coordinator, and always notifies the affected person with a chance
to dispute. A disputed no-show does not count against reliability until resolved.

**BR-HELP-07** Completion records actual duration. Volunteer hours are derived from
completed activities only — never self-declared without a counterpart or coordinator
confirmation.

---

## 5. Family relationships (BR-FAMILY)

**BR-FAMILY-01** A family relationship grants **nothing** by default. Every permission is
granted individually.

**BR-FAMILY-02** Permission set:

```
CanViewActivities
CanViewHelpRequests
CanCreateHelpRequests
CanManageEvents
CanReceiveSafetyNotifications
CanManageProfile
CanBeEmergencyContact
```

**BR-FAMILY-03** Permissions are granted by the senior, or — where the senior cannot use
the app — by an authorised organization staff member, with the reason recorded.
Never by the family member themselves.

**BR-FAMILY-04** The senior can revoke any permission at any time, in one step, and the
revocation takes effect immediately.

**BR-FAMILY-05** A family member **never** sees: private messages, safeguarding cases,
verification documents, or any data about third parties (other seniors, volunteers'
personal details beyond what a senior sees).

**BR-FAMILY-06** Every access by a family member to senior data is written to the audit log.

---

## 6. Safeguarding (BR-SG)

**BR-SG-01** Safeguarding is a **separate subsystem** with its own authorization policy.
It is not an extension of the ordinary reporting feature.

**BR-SG-02** Access requires the explicit `SafeguardingOfficer` capability.
`OrganizationAdmin` does **not** imply it.

**BR-SG-03** A safeguarding case is never deleted, only resolved and archived. Retention
follows a defined policy, separately from ordinary data.

**BR-SG-04** Anyone involved in an activity can raise a concern in one tap. The reporter's
identity is stored but is **not shown** to the subject of the case.

**BR-SG-05** Case data must never appear in ordinary reports, exports, dashboards,
notifications, or search results.

**BR-SG-06** Every read of a safeguarding case is audited, including the reader, timestamp
and the case ID.

---

## 7. Multi-tenancy and scope (BR-TENANT)

**BR-TENANT-01** Scope model:

```
Platform      — visible to everyone
Community     — visible in a geographic area
Organization  — visible only within one organization
Private       — visible only to explicitly invited participants
```

**BR-TENANT-02** `OrganizationId` is **nullable** on Groups, Events and Help Requests.
A null organization is valid and means "independent / community".

**BR-TENANT-03** Organization A can never read Organization B's data. Enforced by a global
query filter **and** verified by an architecture test, not by developer discipline.

**BR-TENANT-04** Cross-organization data aggregation is allowed only for anonymised
platform-level statistics, and only where re-identification is not possible
(minimum cohort size 10).

---

## 8. Audit (BR-AUDIT)

**BR-AUDIT-01** Auditable events (minimum): authentication, trust/verification changes,
help-request state transitions, assignment changes, family-permission changes, any read of
a senior profile by staff, any safeguarding access, data export, data deletion.

**BR-AUDIT-02** Each entry records: actor, action, subject, timestamp (UTC), organization
context, **and the reason where the action requires one**.

**BR-AUDIT-03** Audit entries are append-only. No update, no delete, ever.

---

## 9. Communication (BR-COMM)

**BR-COMM-01** No open private messaging in MVP. Conversations exist only in a context:
a help request, an event, or a group.

**BR-COMM-02** A conversation is closed 14 days after its context completes; content
remains readable to participants for the retention period but no new messages can be sent.

**BR-COMM-03** Report and Block are available in every conversation, on every screen.

**BR-COMM-04** Phone numbers and addresses are revealed only after an assignment is
confirmed, and only to the assigned counterparty — never in a public list.

---

## 10. Data protection (BR-GDPR)

**BR-GDPR-01** Data classes with separate access policies:
`PublicProfile` · `PersonalData` · `SensitiveData` · `HealthRelatedData` · `SafeguardingData`.

**BR-GDPR-02** Health-related data is **avoided by design**. If a limitation must be
recorded, store a functional need ("braucht Begleitung beim Gehen"), never a diagnosis.

**BR-GDPR-03** Every user can export their data (machine-readable) and request deletion
from within the app.

**BR-GDPR-04** Deletion is a two-tier process: personal data erased/anonymised; audit and
safeguarding records retained under the documented legal basis, with personal identifiers
pseudonymised where legally permissible.

**BR-GDPR-05** No third-party analytics, advertising or tracking SDKs. Ever.

**BR-GDPR-06** No real personal data enters any environment before a legal entity,
privacy policy, processing agreement and security review exist. This is a hard gate
before Phase 7.
