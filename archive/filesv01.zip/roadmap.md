# Roadmap — Phases, Scope and Test Gates

> Each phase is **independently shippable and independently testable**. You test each phase
> yourself before the next one starts. A phase is not finished until its Test Gate passes.
>
> Durations assume one experienced developer working with an AI coding agent, part-time.
> They are estimates, not commitments.

---

## Overview

| Phase | Name | Duration | Shippable outcome |
| --- | --- | --- | --- |
| 0 | Discovery & Project Brain | 2–4 w | Documented reality + frozen MVP scope |
| 1 | Foundation | 4–6 w | Login, profiles, theming, i18n, dark mode, audit |
| 2 | Community | 3–4 w | Groups & events — *first user-visible value* |
| 3 | Help & Matching | 5–7 w | The core loop. **First demoable product** |
| 4 | Family & Delegation | 3–4 w | Family-led onboarding — *the growth engine* |
| 5 | Trust & Safeguarding | 4–5 w | Verification, safety levels, safeguarding, insurance |
| 6 | Organizations & Dashboard | 5–7 w | Multi-tenancy, staff web app, impact reporting. **First sellable product** |
| 7 | Pilot Hardening | 4–6 w | GDPR, notifications, offline, monitoring. **Real pilot ready** |
| 8 | Scale & Intelligence | ongoing | AI matching, voice, ID Austria, corporate, white-label |

Total to a real pilot: roughly **8–11 months** part-time. Anyone who tells you 3 months is
selling you something.

---

## Phase 0 — Discovery & Project Brain

**Goal:** stop designing from assumptions.

### Do

- Interview **3 NGO volunteer coordinators**, **1 social worker**, **5 seniors**,
  **5 volunteers**, **1 Gemeinde representative**.
- For each coordinator, get: their actual weekly time breakdown, their top 3 pains, the
  tools they use today, and what their funding report has to contain.
- Write `docs/product/discovery-findings.md` — quotes, not summaries.
- Choose **one pilot Gemeinde** and **one anchor partner**.
- Freeze MVP = Phases 1–3 + the parts of 5 needed for safety.
- Create the Git repository with this whole document tree.
- Set up CI (build, test, lint, format) before any feature code.

### Interview questions to actually ask

```
1. Walk me through last Tuesday, hour by hour.
2. How many volunteers do you coordinate? How do you know who is active?
3. What happens when a volunteer does not show up?
4. How do you record volunteer hours today? Show me.
5. What goes into your annual report? Where do those numbers come from?
6. What checks does a new volunteer go through? How long does that take?
7. Tell me about a time something went wrong with a client.
8. Who is allowed to see sensitive information about a client?
9. What software did you try before? Why did you stop using it?
10. If I could fix exactly ONE thing for you, what would it be?
11. Who signs off on buying software here, and what is that process?
12. What would make you say no to this immediately?
```

### Test Gate 0

```
[ ] 15+ interviews documented with verbatim quotes
[ ] The #1 coordinator pain is written down — and it is NOT an assumption
[ ] One pilot Gemeinde identified and contacted
[ ] MVP scope frozen and written to docs/plans/mvp-scope.md
[ ] Repo + CI green on an empty solution
```

---

## Phase 1 — Foundation

**Goal:** an app you can log into that looks and feels right, in three languages, in both
themes. No business features yet.

### Backend

- ASP.NET Core 8 solution, modular monolith skeleton
- PostgreSQL + EF Core, migrations, seed data
- `Identity` module: registration, login, refresh tokens, email verification, phone (SMS) verification
- `Users` + `Profiles` module: `User`, `SeniorProfile`, `VolunteerProfile`, `Interest`, `Language`, `Skill`
- Capability/authorization framework (policy-based, server-side only)
- `TrustLevel` computed service (levels 0–1 only in this phase)
- `Audit` module: append-only log, interceptor-based
- Global error handling → RFC 7807 `ProblemDetails`
- OpenAPI/Swagger, API versioning (`/api/v1`)
- Health checks, structured logging (Serilog), correlation IDs

### Flutter

- Project scaffold, feature-first structure, flavors (`dev` / `staging` / `prod`)
- **Design system implemented**: `AppColors` (light + dark), `AppTypography`
  (standard + senior scale), `AppSpacing`, `AppRadius`, `AppBreakpoints`, `AppTheme`
- **Dark mode + system mode + persisted preference** — done here, not later
- **Senior Mode toggle** and its separate navigation shell
- `easy_localization` with `de` / `en` / `fa`, German as source of truth, **RTL verified**
- Routing (`go_router`), DI (`get_it` + `injectable`), state (`Cubit` + `freezed`)
- API client with auth interceptor, token refresh, typed errors
- Auth flows: register, login, verify email, verify phone, forgot password
- Profile screens: view, edit, interests, languages, availability
- Shared widgets: `AppButton`, `AppTextField`, `AppCard`, `AppStatusChip`, `AppEmptyState`,
  `AppErrorView`, `AppLoading`, `AppConfirmSheet`

### Test Gate 1

```
[ ] Register → verify email → verify phone → login → edit profile works end to end
[ ] Works in de, en, fa — fa renders correctly RTL, no clipped or mirrored-wrongly icons
[ ] Every screen verified in light AND dark AND system-follows-OS
[ ] Every screen verified at text scale 1.0 / 1.5 / 2.0 without overflow
[ ] Senior Mode toggle changes type scale, touch targets and navigation shell
[ ] TalkBack (Android) and VoiceOver (iOS) can complete the login flow
[ ] No hardcoded user-visible string anywhere (grep for quoted German/English in lib/)
[ ] No hardcoded Colors.* anywhere in lib/features
[ ] Audit log contains an entry for login and for profile change
[ ] API returns ProblemDetails for 400/401/403/404/409/500
[ ] Builds on Android, iOS, and Web (staff app target)
```

---

## Phase 2 — Community

**Goal:** the platform is useful even with no help requests and no organizations.
This is what gives the pilot Gemeinde something to look at on day one.

### Features

- `CommunityGroup`: create, edit, archive; scope (`Platform` / `Community` / `Private`)
- Group membership: join, leave, invite, approve (for private groups)
- Group roles: organizer, member
- `Event`: one-off and **recurring** (weekly / biweekly / monthly)
- Event registration, capacity, waiting list, cancellation
- Location: free-text place + optional lat/lng; distance filter using Haversine
  (PostGIS-ready columns, extension not yet enabled)
- Interest-based discovery: "Gruppen in Ihrer Nähe", "Passt zu Ihren Interessen"
- Group and event detail pages with a simple, contextual conversation thread
- Calendar view: "Meine Aktivitäten" (Senior Mode: a plain vertical list, never a grid calendar)
- Reminders (in-app; push comes in Phase 7)

### Explicitly not in this phase

Public feed, photo sharing, likes, comments on other people's content.

### Test Gate 2

```
[ ] A senior can create a recurring group without any organization involved
[ ] Another user can find it by interest and by distance, and register
[ ] Capacity and waiting list behave correctly under concurrent registration
[ ] Cancelling one occurrence of a recurring event does not cancel the series
[ ] Private group content is invisible to non-members (verified by an API test, not the UI)
[ ] Senior Mode: joining an event takes at most 3 taps from the home screen
[ ] All new screens pass the Phase 1 accessibility, i18n and dark-mode checks
```

---

## Phase 3 — Help & Matching

**Goal:** the core loop. After this you have something to demo.

### Features

- `HelpRequest`: create (categories, date/time window, location, description, recurrence)
- Category catalogue with server-side safety-level mapping (`IActivitySafetyPolicy`)
- **Blocked-category detection → referral flow** (BR-SCOPE-02/03)
- **Emergency detection → emergency screen** (BR-SCOPE-04)
- Full state machine (BR-HELP-01) with legal-transition enforcement
- Rule-based matching: `IVolunteerMatchingService` → `RuleBasedMatchingPolicy`
  - configurable weights: distance 40 · availability 30 · skills/language 20 · trust 10
  - hard filters applied first (trust level, capability, blocked users, workload cap)
- Volunteer-facing "Anfragen in Ihrer Nähe" feed with clear time and effort estimate
- Offer → Accept with the atomic conditional update (BR-HELP-03)
- Check-in / Check-out (time-bounded, activity-scoped; **no background tracking**)
- Completion, duration recording, volunteer hours
- Lightweight mutual feedback (thumbs + optional note) — **not** public star ratings
- Reliability score computed from behaviour (completed / cancelled / no-show / response time)
- Cancellation with reasons; no-show handling with dispute (BR-HELP-06)
- Contextual conversation attached to the request

### Test Gate 3

```
[ ] Senior creates a request → volunteer sees it → accepts → checks in → completes
[ ] Two volunteers accepting simultaneously: exactly one wins, the other gets a clear 409
[ ] A volunteer below the required trust level never appears as a candidate (API-level test)
[ ] Requesting a blocked category shows a referral and creates NO request
[ ] Typing an emergency phrase opens the emergency screen, not a request form
[ ] Matching weights are configurable without a code change
[ ] Volunteer hours total matches the sum of completed activity durations
[ ] Reliability score changes correctly after a no-show, and reverts after a successful dispute
[ ] Full loop completable in Senior Mode with TalkBack enabled
```

---

## Phase 4 — Family & Delegation

**Goal:** the growth engine. Sabine can set up Maria's account.

### Features

- Family relationship: invite by phone/email, senior confirms (or staff confirms on their behalf)
- Granular `FamilyPermission` set (BR-FAMILY-02), granted and revocable by the senior
- **Family-led account creation**: a family member creates and configures a senior account,
  then hands over a login code / QR card
- Acting "on behalf of": every such action shows a clear banner and records both user IDs
- Trusted Contacts with per-event notification rules
  ("notify my daughter when a volunteer checks in")
- Family dashboard (mobile + responsive web): upcoming activities, request status, alerts
- Full audit visibility for the senior: "Wer hat was gesehen?" — a plain-language log
- Safety Alert workflow (distinct from Emergency): missed activity, concern raised,
  welfare-check request

### Test Gate 4

```
[ ] Sabine creates an account for Maria from her own phone; Maria logs in and it is set up
[ ] A family member with no permissions can see literally nothing about the senior
[ ] Granting CanCreateHelpRequests takes effect immediately; revoking it does too
[ ] An on-behalf-of request shows both names to the volunteer and in the audit log
[ ] The senior can see, in plain German, every access to her data in the last 30 days
[ ] A family member cannot see private messages or safeguarding data (API-level test)
```

---

## Phase 5 — Trust & Safeguarding

**Goal:** the phase that makes a real pilot with real people defensible.

### Features

- Verification records: email, phone, identity, address, organization, training, background check
- `IIdentityVerificationProvider` abstraction + `ManualVerificationProvider` +
  `OrganizationVerificationProvider`
- Trust level computation across levels 0–5, with expiry and re-verification reminders
- Capability engine: what this user may do *right now*, and **why not** if they cannot
- Trust badges in the UI with plain-language explanations
- Safety levels enforced across matching, with the reason surfaced to the user
- **Buddy System** for a volunteer's first three Level-3+ activities
- First Meeting Protocol checklist
- **Safeguarding module**: concern reporting (one tap, any context), case creation,
  restricted access policy, assignment, status workflow, notes, resolution, dedicated audit
- Block & report between users
- Insurance context on assignments (BR-SAFETY-06)
- **High-contrast themes** shipped here

### Test Gate 5

```
[ ] An OrganizationAdmin without the SafeguardingOfficer capability gets 403 on every
    safeguarding endpoint — verified by an automated test, not by clicking
[ ] A safeguarding case appears in NO export, report, dashboard, notification or search
[ ] A concern can be raised in ≤ 2 taps from any activity screen
[ ] Expiring a verification lowers the trust level and flags affected assignments
[ ] A volunteer denied a match sees WHY, in plain language, with what to do next
[ ] The buddy rule cannot be bypassed via the API
[ ] Both high-contrast themes pass 7:1 on all text
```

---

## Phase 6 — Organizations & Dashboard

**Goal:** the first thing anyone will pay for.

### Features

- `Organization`, `OrganizationBranch`, `OrganizationMembership`, staff roles
- Multi-tenancy activated: global query filters + **architecture tests** proving isolation
- Organization-scoped groups, events, help requests, volunteers
- Volunteer management: onboarding pipeline, verification queue, training records, hours
- **Coordinator dashboard (Blazor or React web app)** — first widget is
  **"Braucht heute Aufmerksamkeit"**: unmatched requests, no-show risks, expiring verifications
- Impact reporting: hours, people supported, requests completed, activities, attendance,
  repeat participation, fulfilment rate
- PDF impact report export
- CSV/Excel export for the coordinator's own reporting
- Organization branding config (logo, primary colour, support contact) — **dynamic
  branding in one app**, no separate builds yet
- Organization API keys + webhook events (for a future CRM integration)

### Test Gate 6

```
[ ] Org A cannot read a single row belonging to Org B — proven by an architecture test
    and by a manual attempt with a real token
[ ] A community group with organization_id = NULL still works perfectly
[ ] The coordinator dashboard loads in < 2 s with 5 000 seeded records
[ ] The PDF impact report matches the numbers in the database exactly
[ ] Branding change reflects in the mobile app without a rebuild
[ ] Staff web app is keyboard-navigable and screen-reader usable
```

---

## Phase 7 — Pilot Hardening

**Goal:** legally and operationally ready for real people. This is a **gate**, not a feature set.

### Features

- Push notifications (FCM/APNs) + **SMS fallback** for users who do not check the app
- Notification preferences per category and per channel; quiet hours
- Offline read cache: today's activities, contacts, appointments, emergency info
  (Drift/SQLite; sync queue for check-in only)
- Consent management: versioned terms, privacy policy, granular consents, withdrawal
- Data export (JSON + PDF) and deletion request workflow with the two-tier rule
- Retention jobs
- Rate limiting, brute-force protection, account lockout
- Security review: OWASP MASVS for mobile, OWASP ASVS L2 for the API; dependency scanning
- Penetration test (external, even a small one)
- Backups + tested restore, DR runbook
- Monitoring, alerting, error tracking (self-hosted or EU-hosted only)
- Support flow: in-app help, contact, FAQ in simple German
- Onboarding materials: printed QR card, one-page Gemeinde flyer, a 90-second video

### Legal gate — none of this is optional before real data

```
[ ] Legal entity established
[ ] Data Controller / Processor roles defined per participant
[ ] Privacy policy + terms, reviewed by a lawyer
[ ] DPA templates for organizations
[ ] Records of processing (Verarbeitungsverzeichnis)
[ ] DPIA (Datenschutz-Folgenabschätzung) — with vulnerable people involved, assume it is required
[ ] Volunteer insurance question answered in writing
[ ] Hosting in the EU, verified contractually
```

### Test Gate 7

```
[ ] Airplane mode: today's activities and emergency contacts still visible
[ ] A user can export and then delete their data; audit records survive, pseudonymised
[ ] Restore from backup into a clean environment succeeds
[ ] Pen-test findings: zero critical, zero high open
[ ] Notification arrives within 60 s, respects quiet hours, and SMS fallback fires
```

---

## Phase 8 — Scale & Intelligence

Only after real pilot data exists. In rough priority order:

1. **PostGIS** activation + proper geospatial candidate queries
2. **AI-assisted matching** (`HybridMatchingPolicy`) trained on real completion data —
   AI proposes, humans decide, always explainable
3. **Voice input** → structured help request (speech → structure only, never decisions)
4. **Phone-to-App bridge / IVR** for seniors without smartphones — high impact, high effort
5. **ID Austria** integration once accreditation is realistic
6. **Corporate volunteering** + ESG dashboard
7. **White-label** via Flutter flavors, for an organization that asks and pays
8. Partner benefits / recognition (deliberately last, deliberately lightweight)

Permanently parked: payment marketplace, paid care mediation, gamification.

---

## Scope discipline

Every new idea goes into `docs/plans/backlog.md` with a date and a one-line rationale.
It does **not** go into the current phase. The single biggest failure mode for this
project is a 40-feature v1 that never ships.
