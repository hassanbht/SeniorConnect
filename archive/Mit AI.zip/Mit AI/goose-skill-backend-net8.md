---
id: kplus-backend-net8-conventions
name: "Kplus Backend .NET 8 Conventions"
description: "Project-specific conventions for Kplus backend API migration to .NET 8 / ASP.NET Core 8. Repository pattern, DI, EF Core, async/await mandatory."
version: "1.0.0"
author: "Hassan"
tags: ["dotnet8", "aspnetcore8", "backend", "api", "kplus", "conventions"]
scope: ["file", "project", "conversation"]
---

# Kplus Backend .NET 8 Conventions

## Project Overview

- **Name:** KplusMobileAdmin
- **Type:** ASP.NET Core 8 REST API
- **Migration Source:** Legacy .NET Framework / Entity Framework 6
- **Target:** .NET 8 / ASP.NET Core 8 / Entity Framework Core 8
- **Database:** SQL Server
- **Architecture:** Clean Architecture with Repository Pattern
- **DI Container:** Microsoft.Extensions.DependencyInjection
- **Testing:** xUnit
- **Logging:** Serilog (or built-in ILogger<T>)

## Critical Conventions

### ۱. Async/Await is Mandatory

**Every I/O operation must be async. No exceptions.**

**Never:**
```csharp
// ❌ WRONG - Blocking call
var user = db.Users.FirstOrDefault(u => u.Id == id);
var result = someAsyncMethod().Result; // Deadlock!
Task.WaitAll(tasks); // Blocking
```

**Always:**
```csharp
// ✅ CORRECT - All async
var user = await db.Users.FirstOrDefaultAsync(u => u.Id == id);
var result = await someAsyncMethod();
await Task.WhenAll(tasks);
```

**Consequences of breaking this:**
- ⚠️ Deadlock in production
- ⚠️ Thread pool exhaustion
- ⚠️ Performance degradation

### ۲. Dependency Injection: Everything in Program.cs

**Never instantiate services manually:**

```csharp
// ❌ WRONG
public class UserController : ControllerBase
{
    private readonly UserService _service = new UserService(); // BAD!
}

// ❌ WRONG - ServiceLocator pattern (old)
var service = ServiceLocator.GetInstance<UserService>();
```

**Always register in DI and inject via constructor:**

```csharp
// Program.cs
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddDbContext<MyDbContext>(opts =>
    opts.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Controller
[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly IUserService _service;
    
    public UserController(IUserService service) // Constructor injection
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
    }
    
    [HttpGet("{id}")]
    public async Task<IActionResult> GetUser(int id)
    {
        var user = await _service.GetUserAsync(id);
        return user == null ? NotFound() : Ok(user);
    }
}
```

### ۳. Entity Framework Core: No SQL Injection

**Never use string interpolation in SQL:**

```csharp
// ❌ DANGEROUS - SQL injection
var userId = GetUserIdFromRequest();
var sql = $"SELECT * FROM Users WHERE Id = {userId}";
var user = await db.Users.FromSqlRaw(sql).FirstOrDefaultAsync();
```

**Always use parameterized queries or LINQ:**

```csharp
// ✅ SAFE - Parameterized
var userId = GetUserIdFromRequest();
var user = await db.Users
    .FromSqlInterpolated($"SELECT * FROM Users WHERE Id = {userId}")
    .FirstOrDefaultAsync();

// ✅ BEST - LINQ (type-safe)
var user = await db.Users.FirstOrDefaultAsync(u => u.Id == userId);
```

### ۴. Repository Pattern

**Layer structure:**

```
Controllers/
├── UserController.cs         ← HTTP routing only
Services/
├── IUserService.cs           ← Business logic interface
├── UserService.cs            ← Business logic implementation
Repositories/
├── IUserRepository.cs        ← Data access interface
├── UserRepository.cs         ← Data access implementation
Entities/
├── User.cs                   ← Domain model
Dtos/
├── CreateUserRequest.cs
├── UpdateUserRequest.cs
├── UserResponse.cs           ← Response DTO
```

**Example:**

```csharp
// IUserRepository.cs
public interface IUserRepository
{
    Task<User?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<IEnumerable<User>> GetAllAsync(CancellationToken ct = default);
    Task<User> CreateAsync(User user, CancellationToken ct = default);
    Task<User> UpdateAsync(User user, CancellationToken ct = default);
    Task<bool> DeleteAsync(int id, CancellationToken ct = default);
}

// UserRepository.cs
public class UserRepository : IUserRepository
{
    private readonly MyDbContext _context;
    
    public UserRepository(MyDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }
    
    public async Task<User?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        return await _context.Users.FirstOrDefaultAsync(u => u.Id == id, ct);
    }
    
    public async Task<User> CreateAsync(User user, CancellationToken ct = default)
    {
        _context.Users.Add(user);
        await _context.SaveChangesAsync(ct);
        return user;
    }
}
```

### ۵. Service Layer (Business Logic)

```csharp
// IUserService.cs
public interface IUserService
{
    Task<UserResponse?> GetUserAsync(int id, CancellationToken ct = default);
    Task<UserResponse> CreateUserAsync(CreateUserRequest request, CancellationToken ct = default);
}

// UserService.cs
public class UserService : IUserService
{
    private readonly IUserRepository _repository;
    private readonly ILogger<UserService> _logger;
    
    public UserService(IUserRepository repository, ILogger<UserService> logger)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }
    
    public async Task<UserResponse?> GetUserAsync(int id, CancellationToken ct = default)
    {
        var user = await _repository.GetByIdAsync(id, ct);
        if (user == null)
        {
            _logger.LogWarning("User {UserId} not found", id);
            return null;
        }
        
        return new UserResponse
        {
            Id = user.Id,
            Name = user.Name
        };
    }
    
    public async Task<UserResponse> CreateUserAsync(CreateUserRequest request, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
            throw new ValidationException("Name cannot be empty");
        
        var user = new User { Name = request.Name };
        await _repository.CreateAsync(user, ct);
        
        _logger.LogInformation("User {UserId} created", user.Id);
        
        return new UserResponse { Id = user.Id, Name = user.Name };
    }
}
```

### ۶. Nullable Reference Types (Mandatory)

**Enable at file start:**

```csharp
#nullable enable

public class User
{
    public int Id { get; set; }
    public string Name { get; set; }        // Non-nullable
    public string? Bio { get; set; }        // Nullable
    public DateTime CreatedAt { get; set; } // Non-nullable
}

public async Task<User?> GetUserAsync(int id)  // Nullable return
{
    return await _repository.GetByIdAsync(id);
}

public void ProcessUser(User? user)  // Nullable parameter
{
    if (user == null) return;  // Guard clause
    Console.WriteLine(user.Name);  // Safe
}
```

### ۷. Error Handling

**Never bare catch:**

```csharp
// ❌ WRONG
try { ... }
catch (Exception ex) { ... }

// ✅ CORRECT - Specific exceptions
try
{
    await _repository.CreateAsync(user);
}
catch (DbUpdateException ex)
{
    _logger.LogError(ex, "Database error while creating user");
    throw new ApplicationException("Failed to create user", ex);
}
catch (ValidationException ex)
{
    _logger.LogWarning(ex, "Validation error: {Message}", ex.Message);
    return BadRequest(ex.Message);
}
```

### ۸. Logging: Structured & Injected

**Never static logging:**

```csharp
// ❌ WRONG
public class UserService
{
    public void CreateUser(User user)
    {
        Logger.Info($"User {user.Id} created");  // Static
    }
}

// ✅ CORRECT - Injected, structured
public class UserService
{
    private readonly ILogger<UserService> _logger;
    
    public UserService(ILogger<UserService> logger)
    {
        _logger = logger;
    }
    
    public void CreateUser(User user)
    {
        _logger.LogInformation("User {UserId} created", user.Id);  // Structured
    }
}
```

### ۹. Secrets & Configuration

**Never hardcode:**

```csharp
// ❌ WRONG
var connectionString = "Server=localhost;Database=MyDb;User=admin;Password=hardcoded123";

// ✅ CORRECT - appsettings.json + environment variables
// appsettings.json
{
  "ConnectionStrings": {
    "DefaultConnection": "[connection string from environment]"
  }
}

// Program.cs
builder.Services.AddDbContext<MyDbContext>(opts =>
    opts.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
```

### ۱۰. Unit Tests (xUnit)

**Every service and repository must have tests:**

```csharp
public class UserRepositoryTests
{
    [Fact]
    public async Task GetByIdAsync_WithValidId_ReturnsUser()
    {
        // Arrange
        var context = CreateInMemoryContext();
        var user = new User { Id = 1, Name = "John" };
        context.Users.Add(user);
        await context.SaveChangesAsync();
        
        var repository = new UserRepository(context);
        
        // Act
        var result = await repository.GetByIdAsync(1);
        
        // Assert
        Assert.NotNull(result);
        Assert.Equal("John", result.Name);
    }
    
    [Fact]
    public async Task GetByIdAsync_WithInvalidId_ReturnsNull()
    {
        // Arrange
        var context = CreateInMemoryContext();
        var repository = new UserRepository(context);
        
        // Act
        var result = await repository.GetByIdAsync(999);
        
        // Assert
        Assert.Null(result);
    }
}
```

**Coverage target: >70% for all new code.**

### ۱۱. API Endpoints: Status Codes

```csharp
[HttpGet("{id}")]
public async Task<IActionResult> GetUser(int id)
{
    var user = await _service.GetUserAsync(id);
    return user == null 
        ? NotFound()                    // 404
        : Ok(user);                     // 200
}

[HttpPost]
public async Task<IActionResult> CreateUser(CreateUserRequest request)
{
    if (!ModelState.IsValid)
        return BadRequest(ModelState);  // 400
    
    try
    {
        var user = await _service.CreateUserAsync(request);
        return CreatedAtAction(nameof(GetUser), new { id = user.Id }, user); // 201
    }
    catch (ValidationException ex)
    {
        return BadRequest(ex.Message);  // 400
    }
    catch (Exception ex)
    {
        _logger.LogError(ex, "Error creating user");
        return StatusCode(500, "Internal server error"); // 500
    }
}
```

### ۱۲. Database Migrations (EF Core)

**Always commit migrations:**

```bash
# Create migration
dotnet ef migrations add AddUserTable

# Apply to database
dotnet ef database update

# List all migrations
dotnet ef migrations list
```

**Migrations must be:**
- ✅ Idempotent (can run multiple times safely)
- ✅ Reversible (Down method working)
- ✅ Committed to git

---

## File Structure Template

```
KplusMobileAdmin/
│
├── Controllers/
│   ├── UserController.cs
│   ├── DocumentOrderController.cs
│   └── ...
│
├── Services/
│   ├── IUserService.cs
│   ├── UserService.cs
│   ├── IDocumentOrderService.cs
│   └── DocumentOrderService.cs
│
├── Repositories/
│   ├── IUserRepository.cs
│   ├── UserRepository.cs
│   ├── IDocumentOrderRepository.cs
│   └── DocumentOrderRepository.cs
│
├── Entities/
│   ├── User.cs
│   ├── DocumentOrder.cs
│   └── ...
│
├── Dtos/
│   ├── User/
│   │   ├── CreateUserRequest.cs
│   │   ├── UpdateUserRequest.cs
│   │   └── UserResponse.cs
│   ├── DocumentOrder/
│   │   ├── CreateDocumentOrderRequest.cs
│   │   └── DocumentOrderResponse.cs
│   └── ...
│
├── Data/
│   ├── MyDbContext.cs
│   └── Migrations/
│       ├── 20240101000000_InitialCreate.cs
│       └── ...
│
├── Exceptions/
│   ├── ValidationException.cs
│   ├── EntityNotFoundException.cs
│   └── ...
│
├── Tests/
│   ├── RepositoryTests/
│   │   ├── UserRepositoryTests.cs
│   │   └── ...
│   ├── ServiceTests/
│   │   ├── UserServiceTests.cs
│   │   └── ...
│   └── IntegrationTests/
│       ├── UserApiTests.cs
│       └── ...
│
├── Program.cs              ← DI registration
├── appsettings.json        ← Configuration
├── appsettings.Development.json
└── .gitignore
```

---

## Program.cs Template

```csharp
var builder = WebApplicationBuilder.CreateBuilder(args);

// Add services
builder.Services.AddDbContext<MyDbContext>(opts =>
    opts.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Repositories
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IDocumentOrderRepository, DocumentOrderRepository>();

// Services
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IDocumentOrderService, DocumentOrderService>();

// Logging
builder.Services.AddSerilog();

// Authentication
builder.Services.AddAuthentication(...);

// CORS
builder.Services.AddCors(opts => opts.AddPolicy("AllowFrontend",
    builder => builder
        .WithOrigins("https://localhost:3000")
        .AllowAnyMethod()
        .AllowAnyHeader()));

builder.Services.AddControllers();
builder.Services.AddOpenApi();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();
app.UseCors("AllowFrontend");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
```

---

## Goose Integration Rules

When Goose works on this backend:

```
✅ DO:
- Use async/await for ALL I/O (database, HTTP, files)
- Inject dependencies via constructor
- Use Repository pattern (Interface + Implementation)
- EF Core LINQ (not raw SQL)
- Nullable reference types enabled
- Structured logging with ILogger<T>
- Unit tests >70% coverage
- Proper HTTP status codes (200, 201, 400, 404, 500)
- Guard clauses for null checks
- ConfigureAwait(false) in library code

❌ DON'T:
- Task.Result, Task.Wait(), blocking calls
- Manual service instantiation
- Raw SQL with string interpolation
- Static logging
- Hardcoded connection strings, secrets
- Bare catch(Exception)
- Missing await on async operations
- Nullable annotations without proper checks
```

---

## Goose Prompts

### For Controller Migration
```
Migrate legacy DocumentOrderPartialGroupsController to .NET 8:

Old code: [paste legacy code]

Requirements:
- Create Repository (IDocumentOrderPartialGroupRepository)
- Create Service (optional but recommended)
- Update Controller to ASP.NET Core 8
- Add DTOs (Create, Update, Response)
- Write unit tests (>70% coverage)
- All async
- EF Core LINQ (not SqlQuery)
- Proper DI in Program.cs
- Structured logging

Follow kplus-backend-net8-conventions skill.
```

### For New Feature
```
Implement new API feature "CustomerNotifications":

- Create entities, DbContext, migrations
- Implement Repository pattern
- Write Service with business logic
- Create Controller endpoints:
  - POST /api/notifications (create)
  - GET /api/notifications/{customerId} (list)
  - PUT /api/notifications/{id}/mark-read
- Add DTOs
- Unit tests (>70%)
- Follow conventions
```

### For Bug Fix
```
Fix: [Gleap ticket description]

Code location: [file path]
Follow .NET 8 best practices:
- Async/await
- Proper error handling
- Logging
- Tests
```

---

## Code Review Checklist

Before committing, verify:

- [ ] All methods async (Task or Task<T>)
- [ ] No Task.Result, Task.Wait(), blocking calls
- [ ] DI registration in Program.cs
- [ ] Constructor injection (no field injection)
- [ ] EF Core LINQ (no raw SQL)
- [ ] Nullable reference types enabled (#nullable enable)
- [ ] Proper error handling (specific exceptions)
- [ ] ILogger<T> used (not static logging)
- [ ] No hardcoded secrets
- [ ] Unit tests written (>70% coverage)
- [ ] dotnet build succeeds (0 warnings)
- [ ] dotnet test all green
- [ ] Database migrations committed
- [ ] Proper HTTP status codes
- [ ] Guard clauses for nulls

---

## Integration with Goose

Goose will:

1. Read this skill before touching any backend code
2. Follow Repository pattern, DI, async conventions
3. Warn if it detects: blocking calls, bare catch, hardcoded secrets
4. Generate complete Controller → Service → Repository → Tests
5. Ask for clarification on domain logic, validation rules

**Example Goose command:**
```
Migrate DocumentOrderPartialGroupsController to .NET 8 following kplus-backend-net8-conventions skill. Include DTOs, tests, and all necessary setup.
```

Goose will then generate everything following this skill's rules.
