---
id: kplus-flutter-conventions
name: "Kplus Flutter Developer Conventions"
description: "Project-specific conventions and patterns for kplus_mobile_app (Flutter multi-platform: iOS, iPadOS, macOS, Android, Windows)"
version: "1.0.0"
author: "Hassan"
tags: ["flutter", "dart", "mobile", "kplus", "conventions"]
scope: ["file", "project", "conversation"]
---

# Kplus Flutter Developer Conventions

## Project Overview

- **Name:** kplus_mobile_app
- **Repository:** KplusMobileAppFlutter
- **Type:** Enterprise cross-platform Flutter application
- **Platforms:** iOS, iPadS, macOS, Android, Windows (5 platforms simultaneously)
- **Architecture:** Feature-based with Cubit + Freezed
- **State Management:** Cubit (not Bloc)
- **Local Database:** Drift ORM
- **Localization:** easy_localization (German source of truth)
- **Ticketing:** Gleap SDK

## Critical Conventions

### ۱. Architecture Pattern

```
lib/
├── features/
│   ├── feature_name/
│   │   ├── pages/          # UI screens
│   │   ├── cubit/          # State management
│   │   ├── models/         # Domain models (Freezed)
│   │   ├── repositories/   # Data layer
│   │   └── widgets/        # Feature-specific widgets
├── core/
│   ├── di/                 # Dependency injection
│   ├── routes/             # Route definitions
│   ├── utils/              # Utilities
│   └── services/           # Global services
└── l10n/
    ├── de.json             # German (SOURCE OF TRUTH)
    ├── en.json             # English
    └── it.json             # Italian
```

**Rule:** Feature-based structure. Never layer-based (no separate "services" folder outside features).

### ۲. State Management: Cubit + Freezed

**Never write:**
```dart
// ❌ WRONG
class MyState {
  String name;
  MyState({required this.name});
  
  MyState copyWith({String? name}) {
    return MyState(name: name ?? this.name);
  }
}
```

**Always write:**
```dart
// ✅ CORRECT
@freezed
class MyState with _$MyState {
  const factory MyState({
    required String name,
    @Default([]) List<Item> items,
  }) = _MyState;
}

// Cubit
class MyFeatureCubit extends Cubit<MyState> {
  MyFeatureCubit() : super(const MyState(name: ''));
  
  Future<void> loadData() async {
    final items = await repository.fetchItems();
    emit(state.copyWith(items: items)); // Auto-generated
  }
}
```

**Required Packages:**
```yaml
dependencies:
  flutter_bloc: ^8.x
  freezed_annotation: ^2.x

dev_dependencies:
  build_runner: ^2.x
  freezed: ^2.x
```

### ۳. Drift ORM (NOT raw SQL)

**Never:**
```dart
// ❌ DANGEROUS - SQL injection risk
final result = await database.customStatement(
  "SELECT * FROM users WHERE id = ${userId}"
);
```

**Always:**
```dart
// ✅ SAFE - parameterized
final user = await (database.select(database.users)
  ..where((tbl) => tbl.id.equals(userId)))
  .getSingleOrNull();

// For writes, use customUpdate (not customStatement)
await database.customUpdate(
  'UPDATE users SET name = ? WHERE id = ?',
  variables: [newName, userId],
  updates: {database.users}, // Tell Drift which tables to invalidate
);
```

**Why:** `customStatement` doesn't trigger reactive stream updates. `customUpdate` does.

### ۴. Conditional Imports for Platform-Specific Code

**Problem:** Desktop plugins crash iOS at startup.

**Solution:**
```dart
// lib/core/desktop/desktop_init.dart
import 'package:window_manager/window_manager.dart';

Future<void> initDesktop() async {
  await windowManager.ensureInitialized();
}
```

```dart
// lib/core/desktop/desktop_init_stub.dart
Future<void> initDesktop() async {
  // No-op for mobile
}
```

```dart
// lib/main.dart
import 'core/desktop/desktop_init.dart'
    if (dart.library.io) 'core/desktop/desktop_init.dart'
    if (dart.library.html) 'core/desktop/desktop_init_stub.dart' as desktop;

void main() async {
  await desktop.initDesktop(); // Safe on all platforms
  runApp(const MyApp());
}
```

**Never unconditionally import:**
- `window_manager`
- `screen_retriever`
- `firebase_messaging` (Windows doesn't have native support)

### ۵. Localization Workflow

**German is the source of truth. Always edit `de.json` first.**

```json
// de.json (SOURCE)
{
  "settings_title": "Einstellungen",
  "settings_theme": "Design",
  "settings_theme_description": "Wählen Sie das {themeMode} für die App",
  "button_save": "Speichern"
}
```

```json
// en.json (MIRROR)
{
  "settings_title": "Settings",
  "settings_theme": "Theme",
  "settings_theme_description": "Choose the {themeMode} for the app",
  "button_save": "Save"
}
```

**Critical:** Every `{variable}` placeholder must be **identical** across all 3 files.

### ۶. New Screen: 5-Step Checklist

Every new screen requires exactly 5 steps:

1. **Create Feature Folder**
   ```
   lib/features/my_new_feature/
   ├── pages/
   │   └── my_new_screen.dart
   ├── cubit/
   │   ├── my_new_cubit.dart
   │   └── my_new_state.dart (Freezed)
   ├── models/
   ├── repositories/
   └── widgets/
   ```

2. **Define State with Freezed + Cubit**
   ```dart
   @freezed
   class MyNewState with _$MyNewState {
     const factory MyNewState({...}) = _MyNewState;
   }
   
   class MyNewCubit extends Cubit<MyNewState> {...}
   ```

3. **Wire Dependency Injection**
   ```dart
   // In lib/core/di/service_locator.dart
   getIt.registerSingleton<MyNewCubit>(MyNewCubit(...));
   ```

4. **Add Routes**
   ```dart
   // In lib/core/routes/app_routes.dart
   GoRoute(
     path: '/my-new-screen',
     builder: (context, state) => BlocProvider(
       create: (context) => getIt<MyNewCubit>(),
       child: const MyNewScreen(),
     ),
   ),
   ```

5. **Add Localization Keys**
   ```json
   // de.json
   {
     "my_new_screen_title": "Mein neuer Bildschirm",
     "my_new_button": "Klicken Sie"
   }
   ```
   
   Then mirror to `en.json` and `it.json` with identical placeholders.

### ۷. Dependency Override: irondash_engine_context

**Never remove this line from `pubspec.yaml`:**

```yaml
dependency_overrides:
  irondash_engine_context:
    git:
      url: https://github.com/Sabbar-Engineering/irondash_engine_context.git
      ref: [specific-commit-hash]
```

This points to a fork. Removing it **will break the build**.

### ۸. Version Scheme

Use **date-based versioning**, not semantic:

```yaml
# pubspec.yaml
version: 2024.12.25+42  # YYYY.MM.DD+buildNumber
```

### ۹. Package Version Pinning

**Always pin these versions explicitly:**

```yaml
dev_dependencies:
  drift_dev: ^2.14.0     # Not ^2.x
  freezed: ^2.4.0        # Not ^2.x
  build_runner: ^2.4.6   # Not ^2.x
```

Version drift in these causes build failures.

### ۱۰. Known Platform-Specific Bugs

#### iOS Build Issues
- Unconditional desktop imports → Crash on startup
- Missing provisioning profiles → Upload failure
- Podfile.lock conflicts → Clean and rebuild

#### Windows Issues
- `geolocator_windows` epoch bug: Returns 1970 date instead of current date
  ```dart
  if (position.timestamp.year < 2000) {
    // Invalid timestamp, retry
    return await _retryGeoLocation();
  }
  ```

#### Gleap SDK Integration
- iOS: Native CocoaPods version mismatch → Build error
- Push notifications: Must use `registerPushMessageGroup()` before `Gleap.initialize()`

---

## Usage Rules for Goose

When Goose asks to implement a feature:

```
✅ DO:
- Use Cubit + Freezed for state
- Use Drift with `.customUpdate()` for writes
- Add localization keys to de.json first
- Follow 5-step screen checklist
- Test on Windows + iOS before marking done
- Use conditional imports for desktop plugins

❌ DON'T:
- Use raw SQL with customStatement
- Unconditionally import window_manager
- Remove irondash_engine_context override
- Auto-bump drift_dev/freezed versions
- Mix synchronous and async code without clear reason
- Hardcode colors, strings (use theme, localization)
```

---

## Goose Prompts

### For New Screen Implementation
```
Implement a new screen "[Screen Name]" for kplus_mobile_app:
- Requirements: [list]
- Data source: [API/local/mixed]
- Follow 5-step checklist (folder, Cubit, DI, routes, localization)
- Add de.json keys first, then en.json and it.json
- Test on Windows and iOS
```

### For Bug Fix
```
Fix: [description from Gleap ticket]
Platform: [iOS/Android/Windows/macOS or All]
Follow conventions:
- Cubit + Freezed
- No unconditional imports
- Drift for DB access
```

### For Feature from Backend API
```
Integrate API feature [Name]:
- Endpoint: [POST /api/...]
- Response DTO: [paste or describe]
- Create Repository → Service → Cubit → UI
- Localization keys: [list or let me know]
```

---

## Common Anti-Patterns to Avoid

### ❌ Anti-Pattern 1: Direct DbContext Access
```dart
// WRONG
class MyScreen extends StatelessWidget {
  final database = LocalDatabase();
  
  void loadData() {
    final data = database.select(...).get(); // Sync!
  }
}
```

### ✅ Correct: Repository → Cubit → UI
```dart
// CORRECT
class MyScreenCubit extends Cubit<MyScreenState> {
  MyScreenCubit(this._repository) : super(const MyScreenState());
  
  Future<void> loadData() async {
    final data = await _repository.fetchData();
    emit(state.copyWith(items: data));
  }
}
```

---

## File Checklist for Code Review

When creating a PR, verify:

- [ ] New feature in `lib/features/[name]/` (not elsewhere)
- [ ] State is Freezed + Cubit (not manual classes)
- [ ] All DB access via Drift (no raw SQL)
- [ ] Conditional imports for `window_manager`, `screen_retriever`, `firebase_messaging`
- [ ] `irondash_engine_context` override untouched
- [ ] New localization keys in `de.json`, mirrored to `en.json` and `it.json`
- [ ] Tested on Windows and iOS (at minimum)
- [ ] No breaking changes to existing routes/screens
- [ ] No hardcoded secrets, API keys, credentials

---

## Integration with Goose

Goose will:

1. **Read this skill** before touching any Flutter code
2. **Follow conventions** when generating new features
3. **Warn** if it detects anti-patterns
4. **Ask for clarification** on localization, routes, or state

**Example Goose Prompt:**
```
Implement the "DocumentOrderPartialGroups" feature for kplus_mobile_app:

API: GET /api/document-order-partial-groups
Display as list, allow filtering by status
Add to main navigation

Use the kplus-flutter-conventions skill to follow patterns.
```

Goose will then generate everything following this skill's rules.
